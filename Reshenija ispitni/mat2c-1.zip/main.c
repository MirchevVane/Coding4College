#include <stdio.h>
int main() {
int a[100][100];
int i,j,m,n; // m-redici, n-koloni
int zbiro=0;
int zbirv=0;
double razlika=0;
printf("Vnesi broj na redici na matricata: \n");
fflush(stdout);
scanf("%d", &m);
printf("Vnesi broj na koloni na matricata: \n");
fflush(stdout);
scanf("%d", &n);
for(i=0;i<m;i++) {
  for(j=0;j<n;j++) {
    printf("Vnesi vrednost a[%d][%d]\n", i,j);
    fflush(stdout);
    scanf("%d", &a[i][j]);
  }
}
 for(i=0;i<m;i++) {
   for(j=0;j<n;j++) {
     if(i==0 || i==m-1 || j==0 || j==n-1) {
       zbiro=zbiro+a[i][j];
     } else {
       zbirv=zbirv+a[i][j];
     }
   }
 }
  if(zbiro==zbirv) {
    printf("Uslovot e zadovolen.");
  }
  else 
    printf("Uslovot ne e zadovolen, zbirovite se razlikuvaat za : %f", razlika=zbiro-zbirv);
  
  return 0;
}