/*Да се напише програма која за дадена текстуална датотека, чие име се внесува како аргумент од командна
линија, ќе ги најде сите редови кои имаат повеќе од 10 специјални знаци и во втора датотека (чие име исто така
се внесува како аргумент од командна линија) ќе ги испечати редните броеви на таквите редови. На крај во
втората датотека да се испечати и вкупниот број на редови кои имаат повеќе од 10 специјални
знаци.Програмата треба да провери дали корисникот внел влезна и излезна датотека (доколку нема внесено
појавува порака за грешка).
*За специјален знак се смета оној знак кој е различен од буква или бројка. */



/* A$$$...**)))b  Red 1
ABCdef…%$$        Red 3
&_&_**$$%%#A      Postojat 2 takvi reda.
BcDEFg...##@ 
*/


#include <stdio.h>
#include <ctype.h>
#include<string.h>
#include<stdlib.h>
int main(int argc, char *argv[]){
int red=1;
int brojac=0;
char c;
FILE *in_dat;
FILE *out_dat;
if(argc!=3) {
  fprintf(stderr,"Upatstvo: %s \n", argv[0]);
  fprintf(stderr,"<vlezna_datoteka>, <izlezna_datoteka>");
  return -1;
}
if((in_dat=fopen(argv[1], "r"))==NULL) {
  fprintf(stderr,"Ne moze da se otvori datotekata za citanje, no permission");
  return -1;
}
if((out_dat=fopen(argv[2], "w"))==NULL) {
  fprintf(stderr,"Ne moze da se otvori datotekata za pisuvanje, no permission");
  return -1;
}

//ako ima 10 da prestane da broe do '\n'
while((c=fgetc(in_dat))!=EOF) { // kar po kar do eof

    if(!isalpha(c) && !isdigit(c) && !isspace(c) && c!='\n'){ // ne e bukva ni brojka ni nov red ni prazno mest-> specijalen znak
        brojac++; // ako e brojac se zgolemuva
    }else if(c=='\n') { // ako e nov reed
        if(brojac>=10){ // proverka dali ima 10 specijalni karakteri
            fprintf(out_dat, "red %d\n", red); // ako ima pecate u koj red ima
        }
        red++; // redo se zgolemuva bidejki sme dosle do '\n'
        brojac=0;
    }
}
return 0;
}