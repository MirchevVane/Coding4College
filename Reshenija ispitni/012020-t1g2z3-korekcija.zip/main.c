/*Да се напише програма која за дадена текстуална датотека, чие име се внесува како аргумент од командна
линија, ќе ги најде сите редови кои имаат повеќе од 10 специјални знаци и во втора датотека (чие име исто така
се внесува како аргумент од командна линија) ќе ги испечати редните броеви на таквите редови. На крај во
втората датотека да се испечати и вкупниот број на редови кои имаат повеќе од 10 специјални
знаци.Програмата треба да провери дали корисникот внел влезна и излезна датотека (доколку нема внесено
појавува порака за грешка).
*За специјален знак се смета оној знак кој е различен од буква или бројка. */
#include <stdio.h>
#include <ctype.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char *argv[]) {
int red=0, counter=0;
char c;
FILE *in_dat;
FILE *out_dat;
if(argc!=3) {
  fprintf(stderr, "Upatstvo: %s  <vlezna_datoteka>, <izlezna_datoteka>\n", argv[0]);
  return -1;
}
if((in_dat=fopen(argv[1], "r"))==NULL) {
  fprintf(stderr, "Ne moze da se otvori datotekata %s za citanje, no permission", argv[1]);
  return -1;
}
if((out_dat=fopen(argv[2], "w"))==NULL) {
  fprintf(stderr, "Ne moze da se otvori datotekata %s za pisuvanje, no permission", argv[2]);
  return -1;
}
while((c=fgetc(in_dat))!=EOF) {
  if(!isalpha(c) && !isdigit(c)) {
    counter++;
    if(c=='\n') {
      red++;
    }
    if(counter>10) {
      fprintf(out_dat, "Red %d", red);
    }
  }
  fclose(in_dat);
  fclose(out_dat);
}
  return 0;
}