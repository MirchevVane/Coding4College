/*Да се напише главна програма која што ќе дозволи внесување на низа од N
броеви (не повеќе од 100). Програмата треба да го најде максималниот (најголемиот)
елемент на низата. Потоа, програмата треба да креира нова низа (од постоечката низа)
така што секој елемент од новата низа ќе биде разликата (по апсолутна вредност) на
елементот од постоечката низа до максималниот елемент на низата.*/
#include <stdio.h>
#include<stdlib.h>
#include<math.h>
int main() {
int i, n, j, a[100], b[100];
int najgolem=0;
printf("Kolku elementi da ima nizata ? \n");
scanf("%d", &n);
for(i=0;i<n;i++) {
  printf("Vnesi go elementot a[%d]=", i);
  scanf("%d", &a[i]);
}
najgolem=a[0];
for(i=1;i<n;i++) {
  if(najgolem>a[0])
  najgolem=a[i];
}
for(j=0;j<n;j++) {
  b[j]=abs(najgolem-a[i]);
}
printf("Najgolemiot element e %d, vleznata niza %d i izleznata niza %d", najgolem, a[i], b[j]);
  return 0;
}