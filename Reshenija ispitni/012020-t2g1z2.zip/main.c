/*Да се напише програма која ќе дозволи внесување на димензиите на две квадратни матрици од тастатура.
Максималните можни димензии се 50x50. Потоа се вчитуваат елементите на двете матрици соодветно. Ако во
двете матрици на иста позиција во главната дијагонала се наоѓаат исти броеви, тогаш соодветните броеви треба
да се заменат со збирот на броевите што се наоѓаат десно од нив .  */
#include <stdio.h>

int main() {
int a[50][50], b[50][50], i, j, m, n;
printf("Vnesi go redot na prvata kvadratna matrica: \n");
fflush(stdout);
scanf("%d", &m);
printf("Vnesi go redot na vtorata kvadratna matrica: \n");
fflush(stdout);
scanf("%d", &n);
for(i=0;i<m;i++) {
  for(j=0;j<m;j++) {
  printf("Vnesi go elementot a[%d][%d]=", i, j);
  fflush(stdout);
  scanf("%d", &a[i][j]);
}
}
for(i=0;i<n;i++) {
  for(j=0;j<n;j++) {
    printf("Vnesi go elementot b[%d][%d]=", i, j);
    fflush(stdout);
    scanf("%d", &b[i][j]);
  }
}
int l;
if(n<m) {
  l=n;
}
for(int i=0;i<l;i++)
    {
        if(a[i][i] == b[i][i])
        {
            int suma=0,sumb=0;
            for(int j=0;j<n-1;j++)
            {
                suma+=a[i][j+1];
            }
            for(int j=0;j<m-1;j++)
            {
                sumb+=b[i][j+1];
            }
            a[i][i]=suma;
            b[i][i]=sumb;
        }
    }
    for(i=0;i<l;i++) {
      for(j=0;j<n;j++) {
        printf("%d ", a[i][j]);
      }
      printf("\n");
    }
  return 0;
}