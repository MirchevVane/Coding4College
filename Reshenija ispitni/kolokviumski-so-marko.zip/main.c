#include <stdio.h>
#include<string.h>
#include<ctype.h>
int funk(char *niza, char *podnz, int dolzn, int dolzp) {
  int i,j, true=1, isto=0;
  for(i=0;i<dolzn;i++) {
    true=1;
    if(!isspace(*(niza+i))) {
      if(*(niza+i) != *(podnz+j))
      true=0;
    }
    else{
      if(true) {
        isto++;
      }
      j=0;
      true=1;
    }   
  }
  return isto;
}

int main() {
char niza[100];
char podniza[100];
int pati;
printf("Vnesi niza karakteri \n");
fflush(stdout);
gets(niza);
printf("Vnesi podniza za baranje \n");
fflush(stdout);
gets(podniza);
pati= funk(niza, podniza, strlen(niza), strlen(podniza));
printf("Podnizata se pojavuva %d pati \n", pati);

  return 0;
}