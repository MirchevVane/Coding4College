#include <stdio.h>
void printarray(int *pInt, int n){
  int i;
  for(i=0;i<n;i++){
    printf("%d ", *(pInt+i));
  }
}

void swap(int *a, int *b) {
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}

void bubblesort(int *niza, int n){
int i, j;
for(i=0;i<n;i++){
  for(j=0;j<n-i-1;j++){ //n-i-1 za da ne pristapime do element so ne postoe.
    if(niza[j]>niza[j+1]) {
      swap(niza+j, niza+j+1);
      //swap(&niza[j], &niza[j+1]);

    }

  }
}
}

int main() {
int niza[]={2, 3, 1, 4, 7, 12, -5, 2, 3, 5, 6,  8, 9};

bubblesort(niza, 13);
printarray(niza, 13);
  return 0;
}