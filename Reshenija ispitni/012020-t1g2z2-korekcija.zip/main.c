/*Да се напише програма која ќе дозволи внесување на димензиите на матрица од тастатура. Притоа,
максималната сума од бројот на редици и колони што може да ги има матрицата е 100. Програмата треба да
овозможи и внесување на елементите на матрицата, при што треба да биде дозволено внесување само на
единици и нули. Потоа, програмата треба да одреди која редица или колона го содржи најголемиот број на нули
и да испечати за која редица или колона станува збор. Доколку има повеќе редици или колони со максимален
број на нули, да го испечати вкупниот број на вакви редици или колони. */
#include <stdio.h>

int main(int argc, char *argv[]) {
    int red,kol,i,j;
    int matrica[100][100];
    int nulii[100],nuli=0,maks,i_maks,redmaks=1,kolmaks=1;
    printf("vnesi redici i koloni");
    scanf("%d %d" , &red, &kol);
    for(i=0;i<red;i++){
        for(j=0;j<kol;j++){
            printf("vnesi vrednost :");
            scanf("%d" , &matrica[i][j]);
            if(matrica[i][j]!=0 && matrica[i][j]!=1){
                printf("greska! samo nuli i edinici!");
                return -1;
            }
        }
    }
    for(i=0;i<red;i++){
        for(j=0;j<kol;j++){
            if(matrica[i][j]==0) nuli++;
        }
        nulii[i]=nuli;
        nuli=0;
    }
    for (i=0;i<red;i++){
        if (i==0) {
            i_maks=i+1;
            maks=nulii[i];
        }else if (maks<nulii[i]) {
            maks=nulii[i];
            i_maks=i+1;
        }else if (maks==nulii[i]){
            redmaks++;
        }
    }
    for(i=0;i<red;i++){
        for(j=0;j<kol;j++){
            if(matrica[j][i]==0) nuli++;
        }
        nulii[i]=nuli;
        nuli=0;
    }
    for (i=0;i<kol;i++){
        if (i==0) {
            i_maks=i+1;
            maks=nulii[i];
        }
        else if (maks<nulii[i]) {
            maks=nulii[i];
            i_maks=i+1;
        }
        else if(maks==nulii[i]){
            kolmaks++;
        }
    }
    if(kolmaks>1){
        printf("ima %d koloni so maks nuli\n" , kolmaks );
    }else {
        printf("kolona %d ima najvekje nuli : %d nuli\n", i_maks, maks);
    }
    if(redmaks>1){
        printf("ima %d redici so maks nuli\n" , redmaks );
    }else{
        printf("redica %d ima najvekje nuli : %d nuli\n" , i_maks,maks);
    }
    return 0;
}