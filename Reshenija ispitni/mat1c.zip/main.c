#include <stdio.h>

int main() {

int a[100][100];
int i,j,n,m;
int zbir=0; 
int proizvod=1;
printf("Vnesi dimenzii za matricata: \n");
fflush(stdout);
scanf("%d%d", &n, &m); // n-redici, m-koloni
for(i=0;i<n;i++) {
  for(j=0;j<m;j++) {
    printf("Vnesi vrednosti na matricata: a[%d][%d]: \n", i, j);
    fflush(stdout);
    scanf("%d", &a[i][j]);
  }
}
  for(j=0;j<m;j++) {
    for(i=0;i<n;i++) {
      zbir=zbir+a[i][j];
      proizvod=proizvod*a[i][j];
    }
  }
  if(zbir==proizvod) {
    printf("Kolona %d e sovrsena.\n", j);
  }
  else {
    printf("Kolona %d ne e sovrsena.\n", j);
  }
  return 0;
}