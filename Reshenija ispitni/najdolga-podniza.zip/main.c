#include <stdio.h>

void NajdolgaPodniza(int *a, int n, int *length, int *start)//*a e nizata, n e dolzinata na nizata  
{
for(int i=0;i<n;i++) {
  int currLength=1;//momentalna dolzina 1 oti go izminala prviot element
  int currPos=i;//momentalen broj na index
  while(a[i+1]>a[i]) { // se dodeka sledniot element e pogolem od prethodniot
    currLength++; //momentalna niza se zgolemuva
    i++; // so i++ se zgolemuva indexot, so toa currPos;
    if(i==n-1) 
    break;
  }
  if(currLength>*length) {
    *length=currLength;
    *start=currPos;
  }
}
}

int main() {
int niza[]={2, 3, 1, 4, 7, 12, 7, 9, 1};
int i;
int start=0;
int length=1;
NajdolgaPodniza(niza, 9, &length, &start); // povik na funkcijata
printf("%d, %d", length, start);
  return 0;
}