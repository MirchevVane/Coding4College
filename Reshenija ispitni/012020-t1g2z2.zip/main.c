/*Да се напише програма која ќе дозволи внесување на димензиите на матрица од тастатура. Притоа,
максималната сума од бројот на редици и колони што може да ги има матрицата е 100. Програмата треба да
овозможи и внесување на елементите на матрицата, при што треба да биде дозволено внесување само на
единици и нули. Потоа, програмата треба да одреди која редица или колона го содржи најголемиот број на нули
и да испечати за која редица или колона станува збор. Доколку има повеќе редици или колони со максимален
број на нули, да го испечати вкупниот број на вакви редици или колони. */
#include <stdio.h>

int main() {
  int a[100][100], i, j, m, n;
  printf("Kolku redici da ima matricata ?\n");
  fflush(stdout);
  scanf("%d", &m);
  printf("Kolku koloni da ima matricata ? \n");
  fflush(stdout);
  scanf("%d", &n);
  for(i=0;i<m;i++) {
    for(j=0;j<n;j++) {
      printf("Vnesi go elementot a[%d][%d]=", i, j);
      fflush(stdout);
      scanf("%d", &a[i][j]);
      if(a[i][j]!=0 && a[i][j]!=1) {
        printf("Greska, vnesuvaj samo nuli i edinici");
        return -1;
      }
       }
  }
  int brojacred=0, brojackol=0, redica=0, kolona=0;
  for(i=0;i<m;i++) {
    brojacred=0;
    for(j=0;j<n;j++) {
      if(a[i][j]!=1) {
        brojacred++;
        redica=i;
      }
    }
  }
  for(j=0;j<n;j++) {
    brojackol=0;
    for(i=0;i<m;i++) {
    if(a[i][j]!=1) {
      brojackol++;
      kolona=j;
    }
    }
  }
  if(redica>kolona) {
    printf("Redica %d", redica);
    }
  else {
    printf("Kolona %d", kolona);
  }
  return 0;
}