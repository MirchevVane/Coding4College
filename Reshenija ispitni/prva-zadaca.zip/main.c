#include <stdio.h>
#include<string.h>
#include<ctype.h>
void brojac(char *s) {
  int i, bukvi=0, brojki=0; 
  for(i=0;s[i]!='\0';i++) {
    if((s[i]>=65 &&s[i]<=90) ||(s[i]>=97&&s[i]<=122)) {
      bukvi++;
    }
    else if(s[i]>=48 && s[i]<=57) {
      brojki++;
    }
  } printf("Odnosot na bukvite sprema brojkite e %d : %d\n", bukvi, brojki);
}
void isfrli(char *s) {
  int i, j;
  for(i=0;s[i]!='\0';i++) {
    while (!((s[i]>=65&& s[i]<=90) || (s[i]>=97 && s[i]<=122) || (s[i]>=48 && s[i]<=57) || (s[i]='\0'))) {
      for(j=i;s[j]!='\0';j++) {
        s[j]= s[j+1];
      }
    } s[j]='\0';
  } 
}
int main() { 
  char s[100];
  printf("Vnesi ja tekstualnata niza: \n");
  scanf("%s", &s);
isfrli(s);
brojac(s);
  return 0;
}