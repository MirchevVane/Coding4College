/*Да се напише програма која за дадена текстуална датотека, чие име се внесува како аргумент од командна
линија, ќе ги најде сите редови кои имаат повеќе од 10 специјални знаци и во втора датотека (чие име исто така
се внесува како аргумент од командна линија) ќе ги испечати редните броеви на таквите редови. На крај во
втората датотека да се испечати и вкупниот број на редови кои имаат повеќе од 10 специјални
знаци.Програмата треба да провери дали корисникот внел влезна и излезна датотека (доколку нема внесено
појавува порака за грешка).
*За специјален знак се смета оној знак кој е различен од буква или бројка. */
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[])
{
    FILE *in_dat;
    FILE *out_dat;

    if (argc != 3)
    {
        fprintf(stderr, "Upotreba: %s ime_na_datotekata\n", argv[0]);
        return -1;
    }
    if ((in_dat = fopen(argv[1], "r")) == NULL)
    {
        fprintf(stderr, "Ne mozam da ja otvoram datotekata ");
        fprintf(stderr, "%s za citanje\n", argv[1]);
        return -1;
    }
    if ((out_dat = fopen(argv[2], "w")) == NULL)
    {
        fprintf(stderr, "Ne mozam da ja otvoram datotekata ");
        fprintf(stderr, "%s za zapishuvanje\n", argv[2]);
        return -1;
    }

    char c;
    char first, last;
    int whence = 0;
    int in = 0;
    int check = 1;
    while ((c = fgetc(in_dat)) != EOF)
    {
        if (c != '\n')
        {
            if (isalpha(c))
            {
                if (!in)
                {
                    in = 1;
                    first = c;
                }
                else
                {
                    last = c;
                }
            }
            else
            {
                in = 0;
                if (!(first == last))
                {
                    check = 0;
                }
            }
        }
        else
        {
            if (check)
            {
                fseek(in_dat, whence, SEEK_SET);
                while ((c = fgetc(in_dat) != '\n') && (c != EOF))
                {
                    fprintf(out_dat, "%c", c);
                }
            }
            whence = ftell(in_dat);
        }
    }

    fclose(out_dat);
    fclose(in_dat);

    return 0;
}