#include <stdio.h>

/*void swap(int *a, int *b) {
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
} znaci ako se napise bez asterisk i ampersent funkcijata si vazhe samo u nejzinata vnatresnost, ako sakame da a povikame u main pristapuvame do nejzinata adresa so ampersent*/

// opsta formula: TipNaFunkcija ImeFunkcija(TipNaElementi *ImeNaNiza,n/size/golemina whatever toa ne se pishe so *, i sve ostalo se pishe so *) i se se rabote u for ciklusot.
//funkcijata se povikuva u main so slednata naredba: ImeNaFunkcija(ImeNaNiza, BrojNaElementi)
int main() {
  /*int niza[]=1,2,3,4,5, samoto pokazuva niza-->niza[0],
  najcesto se koriste for ciklus za minuvanje na nizata
  *niza++ ili *niza+i se minat site elementi
  primer printf("%d ", *(niza+i)) e isto so niza[i]*/
  int x=5, y=6;
  swap(&x, &y); //tuka e povikot na funkcijata
  printf("%d %d", x, y);
  
  return 0;
}