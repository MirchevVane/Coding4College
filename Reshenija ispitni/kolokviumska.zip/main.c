#include <stdio.h>

int main() {
int a[100][100], i, j, m, n;
printf("Kolku redici da ima matricata ? \n");
fflush(stdout);
scanf("%d", &m);
printf("Kolku koloni da ima matricata ? \n");
fflush(stdout);
scanf("%d", &n);
for(i=0;i<n;i++) {
  for(j=0;j<m;j++) {
    printf("Vnesi go elementot a[%d][%d]=", i, j);
    fflush(stdout);
    scanf("%d", &a[i][j]);
  }
}
printf("Matrica a: \n");
for(i=0;i<n;i++) 
{
  for(j=0;j<m;j++)
  {
    printf("%d", a[i][j]);
  }
  printf("\n");
}
int t=1;//pomosna promenliva za dokazot
i=0, j=0;
int max, maxi;
for(i=0;i<n-1;i++) { //do n-1 taka bara zadacata ne se ispituva poslednata redica
max=a[i][j];
maxi=a[i+1][j];
for(j=0;j<m;j+) 
{
if(max<a[i][j])
max=a[i][j];
if(maxi<a[i+1][j])
maxi=a[i+1][j];
}
if(!(max>maxi))
{
  printf("Uslovot ne e ispolnet, za %d redica \n", i+2);
  t=0;
  break;
}
}
if(t)//proveruva dali t uste e eden ako e eden e ispolnet ako e na vrednost nula ne e ispolnet.
printf("Uslovot e ispolnet. \n:");
  return 0;
}