/*Да се напише програма која за дадена текстуална датотека, чие име се внесува како аргумент од командна
линија, ќе ги најде сите редови кои имаат помалку од 5 големи букви и во втора датотека (чие име исто така се
внесува како аргумент од командна линија) ќе ги испечати редните броеви на таквите редови. На крај во втората
датотека да се испечати и вкупниот број на редови кои имаат помалку од 5 големи букви.
Програмата треба да провери дали корисникот внел влезна и излезна датотека (доколку нема внесено појавува
порака за грешка).
*/
#include <stdio.h>

int main(int argc, char *argv[]) {
int brojac=0, red=0, brojacred=0;
char c;
FILE *in_dat;
FILE out_dat;
if(argc!=3) {
  fprintf("Upatstvo: %s \n", argv[0]);
  fprintf("<vlezna_datoteka>, <izlezna_datoteka>");
  return -1;
}
if((in_dat=fopen(argv[1], "r"))==NULL) {
  fprintf("Ne moze da se otvori datotekata za citanje, no permission");
  return -1;
}
if((out_dat=fopen(argv[2], "w"))==NULL) {
  fprintf("Ne moze da se otvori datotekata za pisuvanje, no permission");
}
while((c=fgetc(in_dat))!=EOF) {
  if(isalpha(c) && isupper(c)) {
    do {
      brojac++;
    } while(c=="\n");
  }
  if(c=="\n") {
    brojacred++;
  }
  if(brojac<5) {
    fprintf("Red %d ", brojacred, out_dat);
  }
}
fclose(in_dat);
fclose(out_dat);
  return 0;
}