#include <stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
// brisenje na redicite so imat pozitivni broevi da se ispecate novata matrica;
int main() {
	int n,m,i,j,brojac=0;
	int matrica[100][100];
	int true[100];
	printf("Vnesi redici i koloki");
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&matrica[i][j]);
		}
	}

	for(i=0;i<n;i++){
		true[i]=1;
		for(j=0;j<m;j++){
			if(matrica[i][j]>=0){
				true=0;
			}
		}
		if(true[i]==1){
			brojac++;
		}
		if(brojac==3){
			break;
		}
	}
	for(i=0;i<n;i++){
		if(true[i]){
		for(j=0;j<m;j++){
			matrica[i][j]=matrica[i+1][j];
			}
		}
	}

	for(i=0;i<n-brojac;i++){
			for(j=0;j<m;j++){
				scanf("%d",&matrica[i][j]);
			}
			printf("\n");
		}

  return 0;
}
