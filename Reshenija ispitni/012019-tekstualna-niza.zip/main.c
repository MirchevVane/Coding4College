#include <stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
//tekstualna niza so pokazuvaci, da gi otstrane cifrite
void otstrani(char *niza, int n) {
  int i, j;
  for(i=0;i<n;i++) {
    if(isdigit(*(niza+i))) {
      for(j=i;j<n;j++) {
        *(niza+j) = *(niza +j+1);
      }
    }
  }
}

int main() {
char niza[100];


printf("Vnesi niza \n");
gets(niza);

otstrani(niza, strlen(niza));
printf("Novata niza e %s", niza);
  return 0;
}