/*Да се напише програма која ќе дозволи внесување на димензиите на матрица од тастатура. Притоа,
максималната сума од бројот на редици и колони што може да ги има матрицата е 100. Програмата треба да
овозможи и внесување на елементите на матрицата, при што треба да биде дозволено внесување само на
единици и нули. Потоа, програмата треба да ја прикаже должината на најголемата патека од последователни
единици во редиците или колоните на матрицата. Доколку има повеќе патеки со максимална должина, да го
испечати вкупниот број на ваквите патеки. 
*/
#include <stdio.h>

int main() {
int a[100][100], i, j, m, n;
printf("Kolku redici da ima matricata ?\n");
fflush(stdout);
scanf("%d", &m);
printf("Kolku koloni da ima matricata ?\n");
fflush(stdout);
scanf("%d", &n);
for(i=0;i<m;i++) {
  for(j=0;j<n;j++) {
    printf("Vnesi go elementot a[%d][%d]=", i, j);
    fflush(stdout);
    scanf("%d", &a[i][j]);
  }
}
int brojac, brojacred, brojackol;
brojac=brojacred=brojackol=0;
for(i=0;i<m;i++) {
  brojacred=0;
  for(j=0;j<n;j++) {
    if(a[i][j]==1){
      brojacred++;
    }
    if(brojacred>brojac) 
    brojac=brojacred;
  }
}
for(j=0;j<n;j++) {
  brojackol=0;
  for(i=0;i<m;i++) {
    if(a[i][j]==1) {
      brojackol++;
    }
    if(brojackol>brojac) 
    brojac=brojackol;
  }
}
printf("Dolzinata iznesuva %d", brojac);
  return 0;
}