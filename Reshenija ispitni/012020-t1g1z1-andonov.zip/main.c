//
// Created by Stefan Andonov on 1/15/21.
//

#include <stdio.h>
void transform(int niza[], int * n) {
    int i, j, k;
    for (i=0;i<*n-1;i++) {
        if (niza[i]>=niza[i+1]) {
            int stara = niza[i+1];
            niza[i+1] = niza[i]+1;
            //1,7,8,10,11,15,20,21
            if (niza[i+1]>2*stara) {
                for (j=i+1;j<*n-1;j++) {
                    niza[j]=niza[j+1];
                }
                --(*n);
                --i;
            }
        }
    }

}

int main() {
    int niza[]={1, 7, 6, 10, 11, 15, 20, 6, -2, 14};
    int i,n = 10;
    transform(niza, &n);
    for (i=0;i<n;i++)
        printf("%d ", niza[i]);
    return 0;
}