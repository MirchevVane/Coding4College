/*Да се напише програма која за дадена текстуална датотека, чие име се
внесува како аргумент од командна линија, ќе ги најде сите лични именки
и ќе ги испечати во втора датотека (чие име исто така се внесува како
аргумент од командна линија), а притоа зборовите да се испечатат во ист
ред како што се запишани во првата датотека. A на крај на екран ќе се
испечати новата датотека.
- Личните именки во македонскиот јазик започнуваат со голема буква.*/
#include <stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
int main(int argc, char *argv[]) {
//vlezna, izlezna, ime na datoteka (!=3)
char c;
FILE *in_dat;
FILE *out_dat;
if(argc!=3) {
  fprintf(stderr,"Upatstvo: %s \n", argv[0]);
  fprintf(stderr, "<vlezna_datoteka>, <izlezna_datoteka>");
  return -1;
}
if((in_dat=fopen(argv[1],"r"))==NULL) {
  fprintf("Ne moze da se otvori datotekata %s za citanje, no permission\n", argv[1]);
  return -1;
}
if((out_dat=fopen(argv[2], "w"))==NULL) {
  fprintf("Ne moze da se otvori datotekata %s za pisuvanje, no permission", argv[2]);
  return -1;
}
while((c=fgetc(in_dat))!=EOF) { //zima karakter po karakter se dodeka ne dojde do end of file
  if(isalpha(c) && !(isspace(c))) { // proveruva dali e bukva i ne e prazno mesto
    if(isupper(c)) { //Ako e golema bukva
      while(!isspace(c)) { // dodeka ne e do prazno mesto
        fprintf(out_dat, "%c", c); //pecati
        c=fgetc(in_dat); //prodolzi da zimash karakteri
      }
      fprintf(" ", out_dat); //uste e u if(isalpha && !isspace)
    }
  }
  if(c=="\n") { //u slucaj ako e nov red
    fprintf("\n", out_dat); // pecati nov red
  }
}
fclose(in_dat);
fclose(out_dat);
  return 0;
}